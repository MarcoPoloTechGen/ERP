import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, productsTable, suppliersTable } from "@workspace/db";
import {
  CreateProductBody,
  GetProductParams,
  UpdateProductParams,
  UpdateProductBody,
  DeleteProductParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/products", async (_req, res): Promise<void> => {
  const products = await db
    .select({
      id: productsTable.id,
      name: productsTable.name,
      unit: productsTable.unit,
      unitPrice: productsTable.unitPrice,
      supplierId: productsTable.supplierId,
      supplierName: suppliersTable.name,
      createdAt: productsTable.createdAt,
    })
    .from(productsTable)
    .leftJoin(suppliersTable, eq(productsTable.supplierId, suppliersTable.id))
    .orderBy(productsTable.createdAt);
  res.json(products.map((p) => ({ ...p, unitPrice: p.unitPrice !== null ? Number(p.unitPrice) : null })));
});

router.post("/products", async (req, res): Promise<void> => {
  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [product] = await db.insert(productsTable).values(parsed.data).returning();
  let supplierName: string | null = null;
  if (product.supplierId) {
    const [sup] = await db.select().from(suppliersTable).where(eq(suppliersTable.id, product.supplierId));
    supplierName = sup?.name ?? null;
  }
  res.status(201).json({ ...product, unitPrice: product.unitPrice !== null ? Number(product.unitPrice) : null, supplierName });
});

router.get("/products/:id", async (req, res): Promise<void> => {
  const params = GetProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [product] = await db
    .select({
      id: productsTable.id,
      name: productsTable.name,
      unit: productsTable.unit,
      unitPrice: productsTable.unitPrice,
      supplierId: productsTable.supplierId,
      supplierName: suppliersTable.name,
      createdAt: productsTable.createdAt,
    })
    .from(productsTable)
    .leftJoin(suppliersTable, eq(productsTable.supplierId, suppliersTable.id))
    .where(eq(productsTable.id, params.data.id));
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  res.json({ ...product, unitPrice: product.unitPrice !== null ? Number(product.unitPrice) : null });
});

router.patch("/products/:id", async (req, res): Promise<void> => {
  const params = UpdateProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [product] = await db
    .update(productsTable)
    .set(parsed.data)
    .where(eq(productsTable.id, params.data.id))
    .returning();
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  let supplierName: string | null = null;
  if (product.supplierId) {
    const [sup] = await db.select().from(suppliersTable).where(eq(suppliersTable.id, product.supplierId));
    supplierName = sup?.name ?? null;
  }
  res.json({ ...product, unitPrice: product.unitPrice !== null ? Number(product.unitPrice) : null, supplierName });
});

router.delete("/products/:id", async (req, res): Promise<void> => {
  const params = DeleteProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [product] = await db.delete(productsTable).where(eq(productsTable.id, params.data.id)).returning();
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
