import { Router, type IRouter } from "express";
import { eq, count, sum } from "drizzle-orm";
import { db, workersTable, projectsTable, suppliersTable, invoicesTable, workerTransactionsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/dashboard/summary", async (_req, res): Promise<void> => {
  const [workerCount] = await db.select({ count: count() }).from(workersTable);
  const [activeProjectCount] = await db.select({ count: count() }).from(projectsTable).where(eq(projectsTable.status, "active"));
  const [supplierCount] = await db.select({ count: count() }).from(suppliersTable);
  const [unpaidCount] = await db.select({ count: count() }).from(invoicesTable).where(eq(invoicesTable.status, "unpaid"));
  const [paidCount] = await db.select({ count: count() }).from(invoicesTable).where(eq(invoicesTable.status, "paid"));
  const [totals] = await db.select({ total: sum(invoicesTable.totalAmount), paid: sum(invoicesTable.paidAmount) }).from(invoicesTable);

  // Per-project invoice summary
  const projects = await db.select().from(projectsTable).orderBy(projectsTable.createdAt);
  const allInvoices = await db.select().from(invoicesTable);

  const projectsSummary = projects.map((p) => {
    const projInvoices = allInvoices.filter((inv) => inv.projectId === p.id);
    const totalInvoiced = projInvoices.reduce((acc, inv) => acc + Number(inv.totalAmount), 0);
    const totalPaid = projInvoices.reduce((acc, inv) => acc + Number(inv.paidAmount), 0);
    return {
      id: p.id,
      name: p.name,
      status: p.status,
      totalInvoiced,
      totalPaid,
      remaining: totalInvoiced - totalPaid,
      invoiceCount: projInvoices.length,
    };
  });

  // Per-worker balance summary
  const workers = await db.select().from(workersTable).orderBy(workersTable.createdAt);
  const allTransactions = await db.select().from(workerTransactionsTable);

  const workersSummary = workers.map((w) => {
    const txs = allTransactions.filter((tx) => tx.workerId === w.id);
    const totalCredit = txs.filter((tx) => tx.type === "credit").reduce((acc, tx) => acc + Number(tx.amount), 0);
    const totalDebit = txs.filter((tx) => tx.type === "debit").reduce((acc, tx) => acc + Number(tx.amount), 0);
    return {
      id: w.id,
      name: w.name,
      role: w.role,
      balance: Number(w.balance),
      totalCredit,
      totalDebit,
    };
  });

  // Per-invoice summary (recent invoices)
  const recentInvoices = await db
    .select({
      id: invoicesTable.id,
      number: invoicesTable.number,
      totalAmount: invoicesTable.totalAmount,
      paidAmount: invoicesTable.paidAmount,
      status: invoicesTable.status,
      supplierName: suppliersTable.name,
      projectName: projectsTable.name,
      invoiceDate: invoicesTable.invoiceDate,
    })
    .from(invoicesTable)
    .leftJoin(suppliersTable, eq(invoicesTable.supplierId, suppliersTable.id))
    .leftJoin(projectsTable, eq(invoicesTable.projectId, projectsTable.id))
    .orderBy(invoicesTable.invoiceDate);

  const invoicesSummary = recentInvoices.map((inv) => ({
    ...inv,
    totalAmount: Number(inv.totalAmount),
    paidAmount: Number(inv.paidAmount),
    remaining: Number(inv.totalAmount) - Number(inv.paidAmount),
  }));

  res.json({
    totalWorkers: workerCount?.count ?? 0,
    activeProjects: activeProjectCount?.count ?? 0,
    totalSuppliers: supplierCount?.count ?? 0,
    invoicesUnpaid: unpaidCount?.count ?? 0,
    invoicesPaid: paidCount?.count ?? 0,
    totalInvoiceAmount: Number(totals?.total ?? 0),
    totalPaidAmount: Number(totals?.paid ?? 0),
    remainingAmount: Number(totals?.total ?? 0) - Number(totals?.paid ?? 0),
    projectsSummary,
    workersSummary,
    invoicesSummary,
  });
});

export default router;
