import { Router, type IRouter } from "express";
import healthRouter from "./health";
import workersRouter from "./workers";
import projectsRouter from "./projects";
import suppliersRouter from "./suppliers";
import productsRouter from "./products";
import invoicesRouter from "./invoices";
import dashboardRouter from "./dashboard";

const router: IRouter = Router();

router.use(healthRouter);
router.use(workersRouter);
router.use(projectsRouter);
router.use(suppliersRouter);
router.use(productsRouter);
router.use(invoicesRouter);
router.use(dashboardRouter);

export default router;
