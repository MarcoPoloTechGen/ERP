import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, invoicesTable, suppliersTable, projectsTable } from "@workspace/db";
import {
  CreateInvoiceBody,
  GetInvoiceParams,
  UpdateInvoiceParams,
  UpdateInvoiceBody,
  DeleteInvoiceParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

const serializeInvoice = (inv: typeof invoicesTable.$inferSelect & { supplierName?: string | null; projectName?: string | null }) => ({
  ...inv,
  totalAmount: Number(inv.totalAmount),
  paidAmount: Number(inv.paidAmount),
});

const invoiceSelect = {
  id: invoicesTable.id,
  number: invoicesTable.number,
  supplierId: invoicesTable.supplierId,
  supplierName: suppliersTable.name,
  projectId: invoicesTable.projectId,
  projectName: projectsTable.name,
  totalAmount: invoicesTable.totalAmount,
  paidAmount: invoicesTable.paidAmount,
  status: invoicesTable.status,
  invoiceDate: invoicesTable.invoiceDate,
  dueDate: invoicesTable.dueDate,
  notes: invoicesTable.notes,
  imageUrl: invoicesTable.imageUrl,
  createdAt: invoicesTable.createdAt,
};

router.get("/invoices", async (_req, res): Promise<void> => {
  const invoices = await db
    .select(invoiceSelect)
    .from(invoicesTable)
    .leftJoin(suppliersTable, eq(invoicesTable.supplierId, suppliersTable.id))
    .leftJoin(projectsTable, eq(invoicesTable.projectId, projectsTable.id))
    .orderBy(invoicesTable.invoiceDate);
  res.json(invoices.map(serializeInvoice));
});

router.post("/invoices", async (req, res): Promise<void> => {
  const parsed = CreateInvoiceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [invoice] = await db.insert(invoicesTable).values(parsed.data).returning();
  let supplierName: string | null = null;
  let projectName: string | null = null;
  if (invoice.supplierId) {
    const [sup] = await db.select().from(suppliersTable).where(eq(suppliersTable.id, invoice.supplierId));
    supplierName = sup?.name ?? null;
  }
  if (invoice.projectId) {
    const [proj] = await db.select().from(projectsTable).where(eq(projectsTable.id, invoice.projectId));
    projectName = proj?.name ?? null;
  }
  res.status(201).json(serializeInvoice({ ...invoice, supplierName, projectName }));
});

router.get("/invoices/:id", async (req, res): Promise<void> => {
  const params = GetInvoiceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [invoice] = await db
    .select(invoiceSelect)
    .from(invoicesTable)
    .leftJoin(suppliersTable, eq(invoicesTable.supplierId, suppliersTable.id))
    .leftJoin(projectsTable, eq(invoicesTable.projectId, projectsTable.id))
    .where(eq(invoicesTable.id, params.data.id));
  if (!invoice) {
    res.status(404).json({ error: "Invoice not found" });
    return;
  }
  res.json(serializeInvoice(invoice));
});

router.patch("/invoices/:id", async (req, res): Promise<void> => {
  const params = UpdateInvoiceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateInvoiceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [invoice] = await db
    .update(invoicesTable)
    .set(parsed.data)
    .where(eq(invoicesTable.id, params.data.id))
    .returning();
  if (!invoice) {
    res.status(404).json({ error: "Invoice not found" });
    return;
  }
  let supplierName: string | null = null;
  let projectName: string | null = null;
  if (invoice.supplierId) {
    const [sup] = await db.select().from(suppliersTable).where(eq(suppliersTable.id, invoice.supplierId));
    supplierName = sup?.name ?? null;
  }
  if (invoice.projectId) {
    const [proj] = await db.select().from(projectsTable).where(eq(projectsTable.id, invoice.projectId));
    projectName = proj?.name ?? null;
  }
  res.json(serializeInvoice({ ...invoice, supplierName, projectName }));
});

router.delete("/invoices/:id", async (req, res): Promise<void> => {
  const params = DeleteInvoiceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [invoice] = await db.delete(invoicesTable).where(eq(invoicesTable.id, params.data.id)).returning();
  if (!invoice) {
    res.status(404).json({ error: "Invoice not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
