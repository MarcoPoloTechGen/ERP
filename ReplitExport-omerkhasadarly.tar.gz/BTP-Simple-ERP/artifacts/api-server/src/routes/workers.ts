import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, workersTable, workerTransactionsTable, projectsTable } from "@workspace/db";
import {
  CreateWorkerBody,
  GetWorkerParams,
  UpdateWorkerParams,
  UpdateWorkerBody,
  DeleteWorkerParams,
  ListWorkerTransactionsParams,
  CreateWorkerTransactionBody,
  CreateWorkerTransactionParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/workers", async (_req, res): Promise<void> => {
  const workers = await db.select().from(workersTable).orderBy(workersTable.createdAt);
  res.json(workers.map((w) => ({ ...w, balance: Number(w.balance) })));
});

router.post("/workers", async (req, res): Promise<void> => {
  const parsed = CreateWorkerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [worker] = await db.insert(workersTable).values(parsed.data).returning();
  res.status(201).json({ ...worker, balance: Number(worker.balance) });
});

router.get("/workers/:id", async (req, res): Promise<void> => {
  const params = GetWorkerParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [worker] = await db.select().from(workersTable).where(eq(workersTable.id, params.data.id));
  if (!worker) {
    res.status(404).json({ error: "Worker not found" });
    return;
  }
  res.json({ ...worker, balance: Number(worker.balance) });
});

router.patch("/workers/:id", async (req, res): Promise<void> => {
  const params = UpdateWorkerParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateWorkerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [worker] = await db
    .update(workersTable)
    .set(parsed.data)
    .where(eq(workersTable.id, params.data.id))
    .returning();
  if (!worker) {
    res.status(404).json({ error: "Worker not found" });
    return;
  }
  res.json({ ...worker, balance: Number(worker.balance) });
});

router.delete("/workers/:id", async (req, res): Promise<void> => {
  const params = DeleteWorkerParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [worker] = await db.delete(workersTable).where(eq(workersTable.id, params.data.id)).returning();
  if (!worker) {
    res.status(404).json({ error: "Worker not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/workers/:id/transactions", async (req, res): Promise<void> => {
  const params = ListWorkerTransactionsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const transactions = await db
    .select({
      id: workerTransactionsTable.id,
      workerId: workerTransactionsTable.workerId,
      projectId: workerTransactionsTable.projectId,
      projectName: projectsTable.name,
      type: workerTransactionsTable.type,
      amount: workerTransactionsTable.amount,
      description: workerTransactionsTable.description,
      date: workerTransactionsTable.date,
      createdAt: workerTransactionsTable.createdAt,
    })
    .from(workerTransactionsTable)
    .leftJoin(projectsTable, eq(workerTransactionsTable.projectId, projectsTable.id))
    .where(eq(workerTransactionsTable.workerId, params.data.id))
    .orderBy(workerTransactionsTable.date);
  res.json(transactions.map((t) => ({ ...t, amount: Number(t.amount) })));
});

router.post("/workers/:id/transactions", async (req, res): Promise<void> => {
  const params = CreateWorkerTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = CreateWorkerTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [transaction] = await db
    .insert(workerTransactionsTable)
    .values({ ...parsed.data, workerId: params.data.id })
    .returning();

  const delta = parsed.data.type === "credit" ? Number(parsed.data.amount) : -Number(parsed.data.amount);
  await db
    .update(workersTable)
    .set({ balance: sql`${workersTable.balance} + ${delta}` })
    .where(eq(workersTable.id, params.data.id));

  let projectName: string | null = null;
  if (transaction.projectId) {
    const [proj] = await db.select().from(projectsTable).where(eq(projectsTable.id, transaction.projectId));
    projectName = proj?.name ?? null;
  }

  res.status(201).json({ ...transaction, amount: Number(transaction.amount), projectName });
});

export default router;
