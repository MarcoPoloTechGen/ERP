import { Link, useRoute } from "wouter";
import { HardHat, Users, FolderOpen, Truck, Package, FileText, LayoutDashboard, Menu, X } from "lucide-react";
import { useState } from "react";
import { useLang, type Lang } from "@/lib/i18n";

function NavItem({ href, label, icon: Icon }: { href: string; label: string; icon: React.ElementType }) {
  const [isActive] = useRoute(href === "/" ? "/" : `${href}/*?`);
  return (
    <Link href={href}>
      <div
        className={`flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-all cursor-pointer ${
          isActive
            ? "bg-sidebar-primary text-sidebar-primary-foreground"
            : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
        }`}
      >
        <Icon size={18} />
        {label}
      </div>
    </Link>
  );
}

const LANGS: { value: Lang; label: string }[] = [
  { value: "en", label: "EN" },
  { value: "ku", label: "کو" },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { t, lang, setLang } = useLang();

  const navItems = [
    { href: "/", label: t.dashboard, icon: LayoutDashboard },
    { href: "/workers", label: t.workers, icon: Users },
    { href: "/projects", label: t.projects, icon: FolderOpen },
    { href: "/suppliers", label: t.suppliers, icon: Truck },
    { href: "/products", label: t.products, icon: Package },
    { href: "/invoices", label: t.invoices, icon: FileText },
  ];

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 z-50 w-60 bg-sidebar flex flex-col transform transition-transform duration-200 md:relative md:translate-x-0 ${
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        } ${t.dir === "rtl" ? "right-0 md:translate-x-0 rtl-sidebar" : "left-0"}`}
        style={t.dir === "rtl" ? { right: 0, left: "auto" } : {}}
      >
        <div className="flex items-center gap-2.5 px-4 py-5 border-b border-sidebar-border">
          <div className="w-8 h-8 bg-sidebar-primary rounded flex items-center justify-center shrink-0">
            <HardHat size={18} className="text-white" />
          </div>
          <div>
            <p className="text-sidebar-foreground font-bold text-sm leading-tight">{t.siteTitle}</p>
            <p className="text-sidebar-foreground/50 text-xs">{t.siteSub}</p>
          </div>
        </div>
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          {navItems.map((item) => (
            <NavItem key={item.href} {...item} />
          ))}
        </nav>
        <div className="p-3 border-t border-sidebar-border">
          <div className="flex items-center justify-between mb-2">
            {LANGS.map((l) => (
              <button
                key={l.value}
                onClick={() => setLang(l.value)}
                className={`flex-1 py-1 text-xs font-semibold rounded transition-colors mx-0.5 ${
                  lang === l.value
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                }`}
              >
                {l.label}
              </button>
            ))}
          </div>
          <p className="text-sidebar-foreground/40 text-xs text-center">{t.version}</p>
        </div>
      </aside>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 md:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile header */}
        <header className="md:hidden flex items-center justify-between px-4 py-3 bg-sidebar border-b border-sidebar-border">
          <div className="flex items-center gap-2">
            <HardHat size={20} className="text-sidebar-primary" />
            <span className="text-sidebar-foreground font-bold text-sm">{t.siteTitle}</span>
          </div>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="text-sidebar-foreground p-1"
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
