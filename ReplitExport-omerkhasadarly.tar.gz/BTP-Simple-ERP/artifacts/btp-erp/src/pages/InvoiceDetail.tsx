import { useParams, Link } from "wouter";
import { useGetInvoice, useUpdateInvoice, getGetInvoiceQueryKey, getListInvoicesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatCurrency, formatDate, statusColors } from "@/lib/format";
import { useLang } from "@/lib/i18n";
import { ArrowLeft, ArrowRight, CheckCircle, ImageIcon } from "lucide-react";
import { useState } from "react";

export default function InvoiceDetail() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id, 10);
  const queryClient = useQueryClient();
  const { t } = useLang();
  const { data: invoiceRaw, isLoading } = useGetInvoice(id, { query: { enabled: !!id, queryKey: getGetInvoiceQueryKey(id) } });
  const updateInvoice = useUpdateInvoice();
  const [imgExpanded, setImgExpanded] = useState(false);

  const invoice = invoiceRaw as typeof invoiceRaw & { imageUrl?: string | null };
  const statusLabels: Record<string, string> = { unpaid: t.unpaid, partial: t.partial, paid: t.paid };

  const markAsPaid = () => {
    if (!invoice) return;
    updateInvoice.mutate(
      { id, data: { paidAmount: invoice.totalAmount, status: "paid" } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetInvoiceQueryKey(id) });
          queryClient.invalidateQueries({ queryKey: getListInvoicesQueryKey() });
        }
      }
    );
  };

  if (isLoading) return <div className="animate-pulse bg-card h-32 rounded-lg" />;
  if (!invoice) return <div className="text-center py-12 text-muted-foreground">{t.notFound}</div>;

  const remaining = invoice.totalAmount - invoice.paidAmount;

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <Link href="/invoices">
          <div className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors cursor-pointer">
            {t.dir === "rtl" ? <ArrowRight size={18} /> : <ArrowLeft size={18} />}
          </div>
        </Link>
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-bold text-foreground">{invoice.number}</h1>
            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[invoice.status]}`}>
              {statusLabels[invoice.status] ?? invoice.status}
            </span>
          </div>
          <p className="text-muted-foreground text-sm">{invoice.supplierName ?? t.noSupplier}</p>
        </div>
        {invoice.status !== "paid" && (
          <button
            onClick={markAsPaid}
            disabled={updateInvoice.isPending}
            className="flex items-center gap-1.5 px-3 py-2 bg-green-600 text-white text-sm font-medium rounded-md hover:bg-green-700 transition-colors"
          >
            <CheckCircle size={16} />
            {t.markPaid}
          </button>
        )}
      </div>

      {/* Invoice image */}
      {invoice.imageUrl && (
        <div className="bg-card border border-card-border rounded-lg p-4">
          <h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
            <ImageIcon size={15} className="text-primary" />
            {t.invoiceImage}
          </h2>
          <img
            src={invoice.imageUrl}
            alt={t.invoiceImage}
            onClick={() => setImgExpanded(!imgExpanded)}
            className={`rounded border border-border cursor-zoom-in object-contain transition-all ${imgExpanded ? "max-h-[60vh] w-full" : "max-h-40"}`}
          />
        </div>
      )}

      <div className="bg-card border border-card-border rounded-lg p-5 space-y-3">
        <h2 className="text-sm font-semibold text-foreground">{t.invoiceDetails}</h2>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div><p className="text-muted-foreground text-xs">{t.supplierOption}</p><p className="font-medium text-foreground">{invoice.supplierName ?? "-"}</p></div>
          <div><p className="text-muted-foreground text-xs">{t.projectOption}</p><p className="font-medium text-foreground">{invoice.projectName ?? "-"}</p></div>
          <div><p className="text-muted-foreground text-xs">{t.invoiceDate}</p><p className="font-medium text-foreground">{formatDate(invoice.invoiceDate)}</p></div>
          <div><p className="text-muted-foreground text-xs">{t.dueDate}</p><p className="font-medium text-foreground">{formatDate(invoice.dueDate)}</p></div>
        </div>
        {invoice.notes && (
          <div>
            <p className="text-muted-foreground text-xs">{t.notes}</p>
            <p className="text-foreground text-sm mt-1">{invoice.notes}</p>
          </div>
        )}
      </div>

      <div className="bg-card border border-card-border rounded-lg p-5">
        <h2 className="text-sm font-semibold text-foreground mb-3">{t.financialSummaryInv}</h2>
        <div className="space-y-2">
          <div className="flex justify-between py-2 border-b border-border">
            <span className="text-sm text-muted-foreground">{t.totalAmount}</span>
            <span className="font-semibold text-foreground">{formatCurrency(invoice.totalAmount)}</span>
          </div>
          <div className="flex justify-between py-2 border-b border-border">
            <span className="text-sm text-muted-foreground">{t.alreadyPaid}</span>
            <span className="font-semibold text-green-700">{formatCurrency(invoice.paidAmount)}</span>
          </div>
          <div className="flex justify-between py-2">
            <span className="text-sm font-medium text-foreground">{t.remaining_label}</span>
            <span className={`font-bold text-lg ${remaining > 0 ? "text-destructive" : "text-green-700"}`}>
              {formatCurrency(remaining)}
            </span>
          </div>
        </div>
        {invoice.totalAmount > 0 && (
          <div className="mt-4">
            <div className="flex justify-between text-xs text-muted-foreground mb-1">
              <span>{t.progress}</span>
              <span>{Math.round((invoice.paidAmount / invoice.totalAmount) * 100)}%</span>
            </div>
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-primary rounded-full transition-all"
                style={{ width: `${Math.min(100, (invoice.paidAmount / invoice.totalAmount) * 100)}%` }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
