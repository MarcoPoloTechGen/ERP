import { useState } from "react";
import { useListProjects, useCreateProject, useUpdateProject, useDeleteProject, getListProjectsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { formatCurrency, formatDate, statusColors } from "@/lib/format";
import { useLang } from "@/lib/i18n";
import { Plus, Pencil, Trash2, ChevronRight } from "lucide-react";
import { useForm } from "react-hook-form";

type ProjectForm = { name: string; client: string; location: string; status: "active" | "completed" | "paused"; budget: string; startDate: string; endDate: string };

function ProjectModal({ project, onClose }: {
  project?: { id: number; name: string; client?: string | null; location?: string | null; status: string; budget?: number | null; startDate?: string | Date | null; endDate?: string | Date | null };
  onClose: () => void;
}) {
  const { t } = useLang();
  const queryClient = useQueryClient();
  const createProject = useCreateProject();
  const updateProject = useUpdateProject();
  const { register, handleSubmit, formState: { errors } } = useForm<ProjectForm>({
    defaultValues: {
      name: project?.name ?? "",
      client: project?.client ?? "",
      location: project?.location ?? "",
      status: (project?.status as "active" | "completed" | "paused") ?? "active",
      budget: project?.budget != null ? String(project.budget) : "",
      startDate: project?.startDate ? new Date(project.startDate).toISOString().split("T")[0] : "",
      endDate: project?.endDate ? new Date(project.endDate).toISOString().split("T")[0] : "",
    }
  });

  const onSubmit = (data: ProjectForm) => {
    const payload = {
      name: data.name,
      client: data.client || null,
      location: data.location || null,
      status: data.status,
      budget: data.budget ? Number(data.budget) : null,
      startDate: data.startDate ? new Date(data.startDate).toISOString() : null,
      endDate: data.endDate ? new Date(data.endDate).toISOString() : null,
    };
    if (project) {
      updateProject.mutate({ id: project.id, data: payload }, {
        onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() }); onClose(); }
      });
    } else {
      createProject.mutate({ data: payload }, {
        onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() }); onClose(); }
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="bg-card border border-card-border rounded-lg shadow-xl w-full max-w-lg">
        <div className="p-5 border-b border-border">
          <h2 className="font-semibold text-foreground">{project ? t.editProject : t.newProject}</h2>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-sm font-medium text-foreground mb-1">{t.projectName} *</label>
              <input {...register("name", { required: true })} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder={t.projectNamePlaceholder} />
              {errors.name && <p className="text-destructive text-xs mt-1">{t.nameRequired}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">{t.client}</label>
              <input {...register("client")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder={t.clientPlaceholder} />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">{t.location}</label>
              <input {...register("location")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder={t.locationPlaceholder} />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">{t.status}</label>
              <select {...register("status")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                <option value="active">{t.active}</option>
                <option value="completed">{t.completed}</option>
                <option value="paused">{t.paused}</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">{t.budget}</label>
              <input type="number" step="0.01" {...register("budget")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder="50000" />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">{t.startDate}</label>
              <input type="date" {...register("startDate")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">{t.endDate}</label>
              <input type="date" {...register("endDate")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm border border-border rounded-md text-foreground hover:bg-muted transition-colors">{t.cancel}</button>
            <button type="submit" className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-md font-medium hover:opacity-90 transition-opacity" disabled={createProject.isPending || updateProject.isPending}>
              {project ? t.save : t.create}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function Projects() {
  const [modal, setModal] = useState<{ open: boolean; project?: Parameters<typeof ProjectModal>[0]["project"] }>({ open: false });
  const { t } = useLang();
  const queryClient = useQueryClient();
  const { data: projects, isLoading } = useListProjects();
  const deleteProject = useDeleteProject();

  const statusLabels: Record<string, string> = { active: t.active, completed: t.completed, paused: t.paused };

  const handleDelete = (id: number) => {
    if (confirm(t.deleteProjectConfirm)) {
      deleteProject.mutate({ id }, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() })
      });
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">{t.projectsTitle}</h1>
          <p className="text-muted-foreground text-sm mt-0.5">{t.project_count(projects?.length ?? 0)}</p>
        </div>
        <button onClick={() => setModal({ open: true })} className="flex items-center gap-1.5 px-3 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:opacity-90 transition-opacity">
          <Plus size={16} />
          {t.addProject}
        </button>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(3)].map((_, i) => <div key={i} className="h-20 bg-card border border-card-border rounded-lg animate-pulse" />)}</div>
      ) : projects?.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground"><p>{t.noProjects}</p></div>
      ) : (
        <div className="space-y-2">
          {projects?.map((p) => (
            <div key={p.id} className="bg-card border border-card-border rounded-lg px-4 py-3 hover:shadow-sm transition-shadow">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-medium text-foreground text-sm">{p.name}</p>
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[p.status]}`}>
                      {statusLabels[p.status] ?? p.status}
                    </span>
                  </div>
                  <p className="text-muted-foreground text-xs mt-0.5">
                    {[p.client, p.location].filter(Boolean).join(" · ") || t.noDetail}
                    {p.startDate && ` · ${t.from} ${formatDate(p.startDate)}`}
                    {p.endDate && ` ${t.to} ${formatDate(p.endDate)}`}
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {p.budget != null && (
                    <span className="text-sm font-semibold text-foreground">{formatCurrency(p.budget)}</span>
                  )}
                  <button onClick={() => setModal({ open: true, project: p })} className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors">
                    <Pencil size={14} />
                  </button>
                  <button onClick={() => handleDelete(p.id)} className="p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded transition-colors">
                    <Trash2 size={14} />
                  </button>
                  <Link href={`/projects/${p.id}`}>
                    <div className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors cursor-pointer">
                      <ChevronRight size={14} />
                    </div>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {modal.open && <ProjectModal project={modal.project} onClose={() => setModal({ open: false })} />}
    </div>
  );
}
