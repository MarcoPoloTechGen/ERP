import { useState } from "react";
import { useListSuppliers, useCreateSupplier, useUpdateSupplier, useDeleteSupplier, getListSuppliersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useLang } from "@/lib/i18n";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { useForm } from "react-hook-form";

type SupplierForm = { name: string; contact: string; phone: string; email: string; address: string };

function SupplierModal({ supplier, onClose }: {
  supplier?: { id: number; name: string; contact?: string | null; phone?: string | null; email?: string | null; address?: string | null };
  onClose: () => void;
}) {
  const { t } = useLang();
  const queryClient = useQueryClient();
  const createSupplier = useCreateSupplier();
  const updateSupplier = useUpdateSupplier();
  const { register, handleSubmit, formState: { errors } } = useForm<SupplierForm>({
    defaultValues: { name: supplier?.name ?? "", contact: supplier?.contact ?? "", phone: supplier?.phone ?? "", email: supplier?.email ?? "", address: supplier?.address ?? "" }
  });

  const onSubmit = (data: SupplierForm) => {
    const payload = { name: data.name, contact: data.contact || null, phone: data.phone || null, email: data.email || null, address: data.address || null };
    if (supplier) {
      updateSupplier.mutate({ id: supplier.id, data: payload }, {
        onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListSuppliersQueryKey() }); onClose(); }
      });
    } else {
      createSupplier.mutate({ data: payload }, {
        onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListSuppliersQueryKey() }); onClose(); }
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="bg-card border border-card-border rounded-lg shadow-xl w-full max-w-md">
        <div className="p-5 border-b border-border">
          <h2 className="font-semibold text-foreground">{supplier ? t.editSupplier : t.newSupplier}</h2>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-3">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.name} *</label>
            <input {...register("name", { required: true })} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder="MatBTP Pro" />
            {errors.name && <p className="text-destructive text-xs mt-1">{t.nameRequired}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.contact}</label>
            <input {...register("contact")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder={t.contactPlaceholder} />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.phoneSup}</label>
            <input {...register("phone")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder={t.phonePlaceholder} />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.email}</label>
            <input type="email" {...register("email")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder={t.emailPlaceholder} />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.address}</label>
            <input {...register("address")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder={t.addressPlaceholder} />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm border border-border rounded-md text-foreground hover:bg-muted transition-colors">{t.cancel}</button>
            <button type="submit" className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-md font-medium hover:opacity-90 transition-opacity" disabled={createSupplier.isPending || updateSupplier.isPending}>
              {supplier ? t.save : t.create}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function Suppliers() {
  const [modal, setModal] = useState<{ open: boolean; supplier?: Parameters<typeof SupplierModal>[0]["supplier"] }>({ open: false });
  const { t } = useLang();
  const queryClient = useQueryClient();
  const { data: suppliers, isLoading } = useListSuppliers();
  const deleteSupplier = useDeleteSupplier();

  const handleDelete = (id: number) => {
    if (confirm(t.deleteSupplierConfirm)) {
      deleteSupplier.mutate({ id }, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: getListSuppliersQueryKey() })
      });
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">{t.suppliersTitle}</h1>
          <p className="text-muted-foreground text-sm mt-0.5">{t.supplier_count(suppliers?.length ?? 0)}</p>
        </div>
        <button onClick={() => setModal({ open: true })} className="flex items-center gap-1.5 px-3 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:opacity-90 transition-opacity">
          <Plus size={16} />
          {t.addSupplier}
        </button>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(3)].map((_, i) => <div key={i} className="h-16 bg-card border border-card-border rounded-lg animate-pulse" />)}</div>
      ) : suppliers?.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground"><p>{t.noSuppliers}</p></div>
      ) : (
        <div className="space-y-2">
          {suppliers?.map((s) => (
            <div key={s.id} className="bg-card border border-card-border rounded-lg px-4 py-3 flex items-center justify-between hover:shadow-sm transition-shadow">
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground text-sm">{s.name}</p>
                <p className="text-muted-foreground text-xs">
                  {[s.contact, s.phone, s.email].filter(Boolean).join(" · ") || t.noDetail}
                </p>
                {s.address && <p className="text-muted-foreground text-xs">{s.address}</p>}
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button onClick={() => setModal({ open: true, supplier: s })} className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors">
                  <Pencil size={14} />
                </button>
                <button onClick={() => handleDelete(s.id)} className="p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded transition-colors">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {modal.open && <SupplierModal supplier={modal.supplier} onClose={() => setModal({ open: false })} />}
    </div>
  );
}
