import { useParams, Link } from "wouter";
import { useGetProject, useListInvoices, getGetProjectQueryKey } from "@workspace/api-client-react";
import { formatCurrency, formatDate, statusColors } from "@/lib/format";
import { useLang } from "@/lib/i18n";
import { ArrowLeft, ArrowRight, FileText } from "lucide-react";

export default function ProjectDetail() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id, 10);
  const { t } = useLang();
  const { data: project, isLoading } = useGetProject(id, { query: { enabled: !!id, queryKey: getGetProjectQueryKey(id) } });
  const { data: allInvoices } = useListInvoices();
  const invoices = allInvoices?.filter((inv) => inv.projectId === id) ?? [];

  const statusLabels: Record<string, string> = { active: t.active, completed: t.completed, paused: t.paused, unpaid: t.unpaid, partial: t.partial, paid: t.paid };

  if (isLoading) return <div className="animate-pulse bg-card h-32 rounded-lg" />;
  if (!project) return <div className="text-center py-12 text-muted-foreground">{t.notFound}</div>;

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <Link href="/projects">
          <div className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors cursor-pointer">
            {t.dir === "rtl" ? <ArrowRight size={18} /> : <ArrowLeft size={18} />}
          </div>
        </Link>
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-bold text-foreground">{project.name}</h1>
            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[project.status]}`}>
              {statusLabels[project.status] ?? project.status}
            </span>
          </div>
          <p className="text-muted-foreground text-sm">{project.client ?? t.noClient}</p>
        </div>
      </div>

      <div className="bg-card border border-card-border rounded-lg p-5">
        <h2 className="text-sm font-semibold text-foreground mb-3">{t.projectInfo}</h2>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div><p className="text-muted-foreground text-xs">{t.location}</p><p className="font-medium text-foreground">{project.location ?? "-"}</p></div>
          <div><p className="text-muted-foreground text-xs">{t.budget}</p><p className="font-medium text-foreground">{project.budget != null ? formatCurrency(project.budget) : "-"}</p></div>
          <div><p className="text-muted-foreground text-xs">{t.startDate}</p><p className="font-medium text-foreground">{formatDate(project.startDate)}</p></div>
          <div><p className="text-muted-foreground text-xs">{t.endDate}</p><p className="font-medium text-foreground">{formatDate(project.endDate)}</p></div>
        </div>
      </div>

      <div>
        <h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
          <FileText size={16} className="text-primary" />
          {t.relatedInvoices_count(invoices.length)}
        </h2>
        {invoices.length === 0 ? (
          <p className="text-muted-foreground text-sm text-center py-6">{t.noInvoicesForProject}</p>
        ) : (
          <div className="space-y-2">
            {invoices.map((inv) => (
              <Link href={`/invoices/${inv.id}`} key={inv.id}>
                <div className="bg-card border border-card-border rounded-lg px-4 py-3 flex items-center justify-between cursor-pointer hover:shadow-sm transition-shadow">
                  <div>
                    <p className="font-medium text-foreground text-sm">{inv.number}</p>
                    <p className="text-muted-foreground text-xs">{inv.supplierName ?? t.noSupplier} · {formatDate(inv.invoiceDate)}</p>
                  </div>
                  <div className="text-end">
                    <p className="font-semibold text-sm text-foreground">{formatCurrency(inv.totalAmount)}</p>
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[inv.status]}`}>
                      {statusLabels[inv.status] ?? inv.status}
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
