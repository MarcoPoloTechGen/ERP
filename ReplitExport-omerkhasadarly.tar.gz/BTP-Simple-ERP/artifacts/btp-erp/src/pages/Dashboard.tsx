import { useGetDashboardSummary } from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/format";
import { useLang } from "@/lib/i18n";
import { Users, FolderOpen, Truck, AlertTriangle, TrendingUp } from "lucide-react";
import { Link } from "wouter";

function StatCard({ icon: Icon, label, value, color }: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  color?: string;
}) {
  return (
    <div className="bg-card border border-card-border rounded-lg p-4 shadow-sm">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-muted-foreground text-xs font-medium uppercase tracking-wide mb-1">{label}</p>
          <p className={`text-2xl font-bold ${color ?? "text-foreground"}`}>{value}</p>
        </div>
        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center shrink-0">
          <Icon size={20} className="text-primary" />
        </div>
      </div>
    </div>
  );
}

const statusColors: Record<string, string> = {
  active: "bg-green-100 text-green-800",
  completed: "bg-blue-100 text-blue-800",
  paused: "bg-yellow-100 text-yellow-800",
  paid: "bg-green-100 text-green-800",
  unpaid: "bg-red-100 text-red-800",
  partial: "bg-orange-100 text-orange-800",
};

export default function Dashboard() {
  const { data, isLoading } = useGetDashboardSummary();
  const { t } = useLang();

  const d = data as typeof data & {
    projectsSummary?: { id: number; name: string; status: string; totalInvoiced: number; totalPaid: number; remaining: number; invoiceCount: number }[];
    workersSummary?: { id: number; name: string; role: string; balance: number; totalCredit: number; totalDebit: number }[];
    invoicesSummary?: { id: number; number: string; totalAmount: number; paidAmount: number; remaining: number; status: string; supplierName?: string | null; projectName?: string | null }[];
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-xl font-bold text-foreground">{t.dashboardTitle}</h1>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-card border border-card-border rounded-lg p-4 h-24 animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const remaining = d?.remainingAmount ?? 0;
  const total = d?.totalInvoiceAmount ?? 0;
  const statusLabels: Record<string, string> = { active: t.active, completed: t.completed, paused: t.paused, unpaid: t.unpaid, partial: t.partial, paid: t.paid };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-foreground">{t.dashboardTitle}</h1>
        <p className="text-muted-foreground text-sm mt-0.5">{t.dashboardSub}</p>
      </div>

      {/* Top stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Users} label={t.totalWorkers} value={d?.totalWorkers ?? 0} />
        <StatCard icon={FolderOpen} label={t.activeProjects} value={d?.activeProjects ?? 0} />
        <StatCard icon={Truck} label={t.totalSuppliers} value={d?.totalSuppliers ?? 0} />
        <StatCard icon={AlertTriangle} label={t.unpaidInvoices} value={d?.invoicesUnpaid ?? 0} color={remaining > 0 ? "text-destructive" : "text-foreground"} />
      </div>

      {/* Financial bar */}
      <div className="bg-card border border-card-border rounded-lg p-5 shadow-sm">
        <h2 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
          <TrendingUp size={16} className="text-primary" />
          {t.financialSummary}
        </h2>
        <div className="grid grid-cols-3 gap-4 mb-3">
          <div>
            <p className="text-xs text-muted-foreground mb-0.5">{t.totalInvoiced}</p>
            <p className="font-bold text-foreground">{formatCurrency(total)}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-0.5">{t.amountPaid}</p>
            <p className="font-bold text-green-700">{formatCurrency(d?.totalPaidAmount ?? 0)}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-0.5">{t.remaining}</p>
            <p className={`font-bold ${remaining > 0 ? "text-destructive" : "text-green-700"}`}>{formatCurrency(remaining)}</p>
          </div>
        </div>
        {total > 0 && (
          <div>
            <div className="flex justify-between text-xs text-muted-foreground mb-1">
              <span>{t.paymentProgress}</span>
              <span>{Math.round(((d?.totalPaidAmount ?? 0) / total) * 100)}%</span>
            </div>
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <div className="h-full bg-primary rounded-full" style={{ width: `${Math.min(100, ((d?.totalPaidAmount ?? 0) / total) * 100)}%` }} />
            </div>
          </div>
        )}
      </div>

      {/* Projects table */}
      <div className="bg-card border border-card-border rounded-lg shadow-sm overflow-hidden">
        <div className="px-4 py-3 border-b border-border">
          <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <FolderOpen size={15} className="text-primary" />
            {t.projectsSummary}
          </h2>
        </div>
        {!d?.projectsSummary?.length ? (
          <p className="text-center py-6 text-muted-foreground text-sm">{t.noneYet}</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="text-start px-4 py-2 text-xs font-medium text-muted-foreground">{t.projectName}</th>
                  <th className="text-start px-4 py-2 text-xs font-medium text-muted-foreground">{t.status}</th>
                  <th className="text-end px-4 py-2 text-xs font-medium text-muted-foreground">{t.invoiced}</th>
                  <th className="text-end px-4 py-2 text-xs font-medium text-muted-foreground">{t.amountPaid}</th>
                  <th className="text-end px-4 py-2 text-xs font-medium text-muted-foreground">{t.remaining}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {d.projectsSummary.map((p) => (
                  <tr key={p.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-2.5 font-medium text-foreground">
                      <Link href={`/projects/${p.id}`}><span className="hover:text-primary cursor-pointer">{p.name}</span></Link>
                    </td>
                    <td className="px-4 py-2.5">
                      <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[p.status] ?? ""}`}>{statusLabels[p.status] ?? p.status}</span>
                    </td>
                    <td className="px-4 py-2.5 text-end text-foreground">{p.invoiceCount > 0 ? formatCurrency(p.totalInvoiced) : "—"}</td>
                    <td className="px-4 py-2.5 text-end text-green-700 font-medium">{p.invoiceCount > 0 ? formatCurrency(p.totalPaid) : "—"}</td>
                    <td className={`px-4 py-2.5 text-end font-semibold ${p.remaining > 0 ? "text-destructive" : p.invoiceCount > 0 ? "text-green-700" : "text-muted-foreground"}`}>
                      {p.invoiceCount > 0 ? formatCurrency(p.remaining) : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Workers table */}
      <div className="bg-card border border-card-border rounded-lg shadow-sm overflow-hidden">
        <div className="px-4 py-3 border-b border-border">
          <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <Users size={15} className="text-primary" />
            {t.workersSummary}
          </h2>
        </div>
        {!d?.workersSummary?.length ? (
          <p className="text-center py-6 text-muted-foreground text-sm">{t.noneYet}</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="text-start px-4 py-2 text-xs font-medium text-muted-foreground">{t.name}</th>
                  <th className="text-start px-4 py-2 text-xs font-medium text-muted-foreground">{t.role}</th>
                  <th className="text-end px-4 py-2 text-xs font-medium text-muted-foreground">{t.totalCredit}</th>
                  <th className="text-end px-4 py-2 text-xs font-medium text-muted-foreground">{t.totalDebit}</th>
                  <th className="text-end px-4 py-2 text-xs font-medium text-muted-foreground">{t.balance}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {d.workersSummary.map((w) => (
                  <tr key={w.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-2.5 font-medium text-foreground">
                      <Link href={`/workers/${w.id}`}><span className="hover:text-primary cursor-pointer">{w.name}</span></Link>
                    </td>
                    <td className="px-4 py-2.5 text-muted-foreground">{w.role}</td>
                    <td className="px-4 py-2.5 text-end text-green-700">{formatCurrency(w.totalCredit)}</td>
                    <td className="px-4 py-2.5 text-end text-orange-600">{formatCurrency(w.totalDebit)}</td>
                    <td className={`px-4 py-2.5 text-end font-bold ${w.balance >= 0 ? "text-green-700" : "text-destructive"}`}>{formatCurrency(w.balance)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Invoices table */}
      <div className="bg-card border border-card-border rounded-lg shadow-sm overflow-hidden">
        <div className="px-4 py-3 border-b border-border">
          <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <AlertTriangle size={15} className="text-primary" />
            {t.invoicesSummary}
          </h2>
        </div>
        {!d?.invoicesSummary?.length ? (
          <p className="text-center py-6 text-muted-foreground text-sm">{t.noneYet}</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="text-start px-4 py-2 text-xs font-medium text-muted-foreground">{t.invoiceNumber}</th>
                  <th className="text-start px-4 py-2 text-xs font-medium text-muted-foreground">{t.supplierOption}</th>
                  <th className="text-start px-4 py-2 text-xs font-medium text-muted-foreground">{t.status}</th>
                  <th className="text-end px-4 py-2 text-xs font-medium text-muted-foreground">{t.totalAmount}</th>
                  <th className="text-end px-4 py-2 text-xs font-medium text-muted-foreground">{t.alreadyPaid}</th>
                  <th className="text-end px-4 py-2 text-xs font-medium text-muted-foreground">{t.due}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {d.invoicesSummary.map((inv) => (
                  <tr key={inv.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-2.5 font-medium text-foreground">
                      <Link href={`/invoices/${inv.id}`}><span className="hover:text-primary cursor-pointer">{inv.number}</span></Link>
                    </td>
                    <td className="px-4 py-2.5 text-muted-foreground">{inv.supplierName ?? "—"}</td>
                    <td className="px-4 py-2.5">
                      <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[inv.status] ?? ""}`}>{statusLabels[inv.status] ?? inv.status}</span>
                    </td>
                    <td className="px-4 py-2.5 text-end text-foreground">{formatCurrency(inv.totalAmount)}</td>
                    <td className="px-4 py-2.5 text-end text-green-700">{formatCurrency(inv.paidAmount)}</td>
                    <td className={`px-4 py-2.5 text-end font-semibold ${inv.remaining > 0 ? "text-destructive" : "text-green-700"}`}>{formatCurrency(inv.remaining)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
