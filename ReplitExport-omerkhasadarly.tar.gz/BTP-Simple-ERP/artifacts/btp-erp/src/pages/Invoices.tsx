import { useState, useRef } from "react";
import { useListInvoices, useCreateInvoice, useUpdateInvoice, useDeleteInvoice, useListSuppliers, useListProjects, getListInvoicesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { formatCurrency, formatDate, statusColors } from "@/lib/format";
import { useLang } from "@/lib/i18n";
import { Plus, Pencil, Trash2, ChevronRight, ImageIcon } from "lucide-react";
import { useForm } from "react-hook-form";

type InvoiceForm = {
  number: string; supplierId: string; projectId: string;
  totalAmount: string; paidAmount: string;
  status: "unpaid" | "partial" | "paid";
  invoiceDate: string; dueDate: string; notes: string;
};

function ImageUpload({ value, onChange }: { value?: string | null; onChange: (v: string | null) => void }) {
  const { t } = useLang();
  const inputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(value ?? null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setPreview(dataUrl);
      onChange(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div>
      <label className="block text-sm font-medium text-foreground mb-1">{t.invoiceImage}</label>
      {preview ? (
        <div className="relative inline-block">
          <img src={preview} alt="invoice" className="h-24 w-auto rounded border border-border object-contain" />
          <button
            type="button"
            onClick={() => { setPreview(null); onChange(null); if (inputRef.current) inputRef.current.value = ""; }}
            className="absolute -top-2 -end-2 w-5 h-5 bg-destructive text-white rounded-full text-xs flex items-center justify-center"
          >✕</button>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="flex items-center gap-2 px-3 py-2 border border-dashed border-border rounded-md text-sm text-muted-foreground hover:border-primary hover:text-primary transition-colors"
        >
          <ImageIcon size={16} />
          {t.uploadImage}
        </button>
      )}
      <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />
    </div>
  );
}

function InvoiceModal({ invoice, onClose }: {
  invoice?: {
    id: number; number: string; supplierId?: number | null; projectId?: number | null;
    totalAmount: number; paidAmount: number; status: string;
    invoiceDate: string | Date; dueDate?: string | Date | null; notes?: string | null; imageUrl?: string | null;
  };
  onClose: () => void;
}) {
  const { t } = useLang();
  const queryClient = useQueryClient();
  const createInvoice = useCreateInvoice();
  const updateInvoice = useUpdateInvoice();
  const { data: suppliers } = useListSuppliers();
  const { data: projects } = useListProjects();
  const [imageUrl, setImageUrl] = useState<string | null>(invoice?.imageUrl ?? null);
  const { register, handleSubmit, formState: { errors } } = useForm<InvoiceForm>({
    defaultValues: {
      number: invoice?.number ?? "",
      supplierId: invoice?.supplierId != null ? String(invoice.supplierId) : "",
      projectId: invoice?.projectId != null ? String(invoice.projectId) : "",
      totalAmount: invoice?.totalAmount != null ? String(invoice.totalAmount) : "",
      paidAmount: invoice?.paidAmount != null ? String(invoice.paidAmount) : "0",
      status: (invoice?.status as "unpaid" | "partial" | "paid") ?? "unpaid",
      invoiceDate: invoice?.invoiceDate ? new Date(invoice.invoiceDate).toISOString().split("T")[0] : new Date().toISOString().split("T")[0],
      dueDate: invoice?.dueDate ? new Date(invoice.dueDate).toISOString().split("T")[0] : "",
      notes: invoice?.notes ?? "",
    }
  });

  const onSubmit = (data: InvoiceForm) => {
    const payload = {
      number: data.number,
      supplierId: data.supplierId ? Number(data.supplierId) : null,
      projectId: data.projectId ? Number(data.projectId) : null,
      totalAmount: Number(data.totalAmount),
      paidAmount: Number(data.paidAmount),
      status: data.status,
      invoiceDate: new Date(data.invoiceDate).toISOString(),
      dueDate: data.dueDate ? new Date(data.dueDate).toISOString() : null,
      notes: data.notes || null,
      imageUrl: imageUrl ?? null,
    };
    if (invoice) {
      updateInvoice.mutate({ id: invoice.id, data: payload }, {
        onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListInvoicesQueryKey() }); onClose(); }
      });
    } else {
      createInvoice.mutate({ data: payload }, {
        onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListInvoicesQueryKey() }); onClose(); }
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto">
      <div className="bg-card border border-card-border rounded-lg shadow-xl w-full max-w-lg my-4">
        <div className="p-5 border-b border-border">
          <h2 className="font-semibold text-foreground">{invoice ? t.editInvoice : t.newInvoice}</h2>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">{t.invoiceNumber} *</label>
              <input {...register("number", { required: true })} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder={t.invoiceNumberPlaceholder} />
              {errors.number && <p className="text-destructive text-xs mt-1">{t.nameRequired}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">{t.invoiceStatus_label}</label>
              <select {...register("status")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                <option value="unpaid">{t.unpaid}</option>
                <option value="partial">{t.partial}</option>
                <option value="paid">{t.paid}</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">{t.supplierOption}</label>
              <select {...register("supplierId")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                <option value="">{t.noneOption}</option>
                {suppliers?.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">{t.projectOption}</label>
              <select {...register("projectId")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                <option value="">{t.noneOption}</option>
                {projects?.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">{t.totalAmount} *</label>
              <input type="number" step="0.01" {...register("totalAmount", { required: true })} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder="4500.00" />
              {errors.totalAmount && <p className="text-destructive text-xs mt-1">{t.amountRequired}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">{t.paidAmount}</label>
              <input type="number" step="0.01" {...register("paidAmount")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder="0.00" />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">{t.invoiceDate} *</label>
              <input type="date" {...register("invoiceDate", { required: true })} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">{t.dueDate}</label>
              <input type="date" {...register("dueDate")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.notes}</label>
            <textarea {...register("notes")} rows={2} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring resize-none" placeholder={t.notesPlaceholder} />
          </div>
          <ImageUpload value={imageUrl} onChange={setImageUrl} />
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm border border-border rounded-md text-foreground hover:bg-muted transition-colors">{t.cancel}</button>
            <button type="submit" className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-md font-medium hover:opacity-90 transition-opacity" disabled={createInvoice.isPending || updateInvoice.isPending}>
              {invoice ? t.save : t.create}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function Invoices() {
  const [modal, setModal] = useState<{ open: boolean; invoice?: Parameters<typeof InvoiceModal>[0]["invoice"] }>({ open: false });
  const [filter, setFilter] = useState<string>("all");
  const { t } = useLang();
  const queryClient = useQueryClient();
  const { data: invoices, isLoading } = useListInvoices();
  const deleteInvoice = useDeleteInvoice();

  const invList = invoices as (typeof invoices extends (infer T)[] ? T & { imageUrl?: string | null } : never)[] | undefined;
  const statusLabels: Record<string, string> = { unpaid: t.unpaid, partial: t.partial, paid: t.paid };

  const handleDelete = (id: number) => {
    if (confirm(t.deleteInvoiceConfirm)) {
      deleteInvoice.mutate({ id }, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: getListInvoicesQueryKey() })
      });
    }
  };

  const filtered = filter === "all" ? invList : invList?.filter((inv) => inv.status === filter);

  const filterLabels: [string, string][] = [
    ["all", t.all],
    ["unpaid", t.unpaidFilter],
    ["partial", t.partialFilter],
    ["paid", t.paidFilter],
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">{t.invoicesTitle}</h1>
          <p className="text-muted-foreground text-sm mt-0.5">{t.invoice_count(invList?.length ?? 0)}</p>
        </div>
        <button onClick={() => setModal({ open: true })} className="flex items-center gap-1.5 px-3 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:opacity-90 transition-opacity">
          <Plus size={16} />
          {t.addInvoice}
        </button>
      </div>

      <div className="flex gap-2 flex-wrap">
        {filterLabels.map(([val, label]) => (
          <button
            key={val}
            onClick={() => setFilter(val)}
            className={`px-3 py-1.5 text-xs font-medium rounded-full border transition-colors ${filter === val ? "bg-primary text-primary-foreground border-primary" : "bg-card text-muted-foreground border-border hover:border-primary/50"}`}
          >
            {label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(3)].map((_, i) => <div key={i} className="h-16 bg-card border border-card-border rounded-lg animate-pulse" />)}</div>
      ) : filtered?.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground"><p>{t.noInvoices}</p></div>
      ) : (
        <div className="space-y-2">
          {filtered?.map((inv) => (
            <div key={inv.id} className="bg-card border border-card-border rounded-lg px-4 py-3 flex items-center justify-between hover:shadow-sm transition-shadow">
              <div className="flex items-center gap-3 flex-1 min-w-0">
                {inv.imageUrl && (
                  <img src={inv.imageUrl} alt="" className="w-10 h-10 object-cover rounded border border-border shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-medium text-foreground text-sm">{inv.number}</p>
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[inv.status]}`}>
                      {statusLabels[inv.status] ?? inv.status}
                    </span>
                  </div>
                  <p className="text-muted-foreground text-xs mt-0.5">
                    {[inv.supplierName, inv.projectName, formatDate(inv.invoiceDate)].filter(Boolean).join(" · ")}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <div className="text-end">
                  <p className="font-semibold text-sm text-foreground">{formatCurrency(inv.totalAmount)}</p>
                  {inv.status !== "paid" && (
                    <p className="text-destructive text-xs">{t.remaining_label}: {formatCurrency(inv.totalAmount - inv.paidAmount)}</p>
                  )}
                </div>
                <button onClick={() => setModal({ open: true, invoice: inv })} className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors">
                  <Pencil size={14} />
                </button>
                <button onClick={() => handleDelete(inv.id)} className="p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded transition-colors">
                  <Trash2 size={14} />
                </button>
                <Link href={`/invoices/${inv.id}`}>
                  <div className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors cursor-pointer">
                    <ChevronRight size={14} />
                  </div>
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}

      {modal.open && <InvoiceModal invoice={modal.invoice} onClose={() => setModal({ open: false })} />}
    </div>
  );
}
