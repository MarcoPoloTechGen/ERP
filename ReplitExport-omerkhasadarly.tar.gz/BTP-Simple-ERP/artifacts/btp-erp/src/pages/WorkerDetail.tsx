import { useParams, Link } from "wouter";
import { useGetWorker, useListWorkerTransactions, useCreateWorkerTransaction, useListProjects, getListWorkerTransactionsQueryKey, getGetWorkerQueryKey, getListWorkersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatCurrency, formatDate } from "@/lib/format";
import { useLang } from "@/lib/i18n";
import { ArrowLeft, ArrowRight, Plus, TrendingUp, TrendingDown } from "lucide-react";
import { useForm } from "react-hook-form";
import { useState } from "react";

type TxForm = { type: "debit" | "credit"; amount: number; description: string; date: string; projectId: string };

function TxModal({ workerId, onClose }: { workerId: number; onClose: () => void }) {
  const { t } = useLang();
  const queryClient = useQueryClient();
  const createTx = useCreateWorkerTransaction();
  const { data: projects } = useListProjects();
  const { register, handleSubmit, formState: { errors } } = useForm<TxForm>({
    defaultValues: { type: "credit", date: new Date().toISOString().split("T")[0], projectId: "" }
  });

  const onSubmit = (data: TxForm) => {
    createTx.mutate(
      { id: workerId, data: {
        type: data.type,
        amount: Number(data.amount),
        description: data.description || null,
        date: new Date(data.date).toISOString(),
        projectId: data.projectId ? Number(data.projectId) : null,
      }},
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListWorkerTransactionsQueryKey(workerId) });
          queryClient.invalidateQueries({ queryKey: getGetWorkerQueryKey(workerId) });
          queryClient.invalidateQueries({ queryKey: getListWorkersQueryKey() });
          onClose();
        }
      }
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="bg-card border border-card-border rounded-lg shadow-xl w-full max-w-md">
        <div className="p-5 border-b border-border">
          <h2 className="font-semibold text-foreground">{t.newTransaction}</h2>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.type} *</label>
            <select {...register("type")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
              <option value="credit">{t.credit}</option>
              <option value="debit">{t.debit}</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.amount} *</label>
            <input type="number" step="0.01" min="0.01" {...register("amount", { required: true, min: 0.01 })} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder="500.00" />
            {errors.amount && <p className="text-destructive text-xs mt-1">{t.amountRequired}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.txProject}</label>
            <select {...register("projectId")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
              <option value="">{t.noProjectOption}</option>
              {projects?.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.description}</label>
            <input {...register("description")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.date} *</label>
            <input type="date" {...register("date", { required: true })} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            {errors.date && <p className="text-destructive text-xs mt-1">{t.dateRequired}</p>}
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm border border-border rounded-md text-foreground hover:bg-muted transition-colors">{t.cancel}</button>
            <button type="submit" className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-md font-medium hover:opacity-90 transition-opacity" disabled={createTx.isPending}>
              {t.create}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function WorkerDetail() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id, 10);
  const [showModal, setShowModal] = useState(false);
  const { t } = useLang();
  const { data: worker, isLoading: loadingWorker } = useGetWorker(id, { query: { enabled: !!id, queryKey: getGetWorkerQueryKey(id) } });
  const { data: transactions, isLoading: loadingTx } = useListWorkerTransactions(id, { query: { enabled: !!id, queryKey: getListWorkerTransactionsQueryKey(id) } });

  const txList = transactions as (typeof transactions extends (infer T)[] ? T & { projectId?: number | null; projectName?: string | null } : never)[] | undefined;

  if (loadingWorker) return <div className="animate-pulse bg-card h-32 rounded-lg" />;
  if (!worker) return <div className="text-center py-12 text-muted-foreground">{t.notFound}</div>;

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <Link href="/workers">
          <div className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors cursor-pointer">
            {t.dir === "rtl" ? <ArrowRight size={18} /> : <ArrowLeft size={18} />}
          </div>
        </Link>
        <div className="flex-1">
          <h1 className="text-xl font-bold text-foreground">{worker.name}</h1>
          <p className="text-muted-foreground text-sm">{worker.role}{worker.phone ? ` · ${worker.phone}` : ""}</p>
        </div>
        <div className="text-end">
          <p className={`text-xl font-bold ${worker.balance >= 0 ? "text-green-700" : "text-destructive"}`}>
            {formatCurrency(worker.balance)}
          </p>
          <p className="text-muted-foreground text-xs">{worker.balance >= 0 ? t.positiveBalance : t.negativeBalance}</p>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-foreground">{t.transactions}</h2>
        <button onClick={() => setShowModal(true)} className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground text-xs font-medium rounded-md hover:opacity-90 transition-opacity">
          <Plus size={14} />
          {t.addTransaction}
        </button>
      </div>

      {loadingTx ? (
        <div className="space-y-2">{[...Array(3)].map((_, i) => <div key={i} className="h-12 bg-card border border-card-border rounded-lg animate-pulse" />)}</div>
      ) : txList?.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground text-sm">{t.noTransactions}</div>
      ) : (
        <div className="space-y-2">
          {[...(txList ?? [])].reverse().map((tx) => (
            <div key={tx.id} className="bg-card border border-card-border rounded-lg px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tx.type === "credit" ? "bg-green-100" : "bg-red-100"}`}>
                  {tx.type === "credit"
                    ? <TrendingUp size={14} className="text-green-700" />
                    : <TrendingDown size={14} className="text-red-700" />}
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">{tx.description ?? (tx.type === "credit" ? t.creditLabel : t.debitLabel)}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatDate(tx.date)}
                    {tx.projectName ? ` · ${tx.projectName}` : ""}
                  </p>
                </div>
              </div>
              <p className={`font-semibold text-sm ${tx.type === "credit" ? "text-green-700" : "text-destructive"}`}>
                {tx.type === "credit" ? "+" : "-"}{formatCurrency(tx.amount)}
              </p>
            </div>
          ))}
        </div>
      )}

      {showModal && <TxModal workerId={id} onClose={() => setShowModal(false)} />}
    </div>
  );
}
