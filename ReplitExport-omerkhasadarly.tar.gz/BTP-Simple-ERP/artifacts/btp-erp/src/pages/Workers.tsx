import { useState } from "react";
import { useListWorkers, useCreateWorker, useUpdateWorker, useDeleteWorker, getListWorkersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { formatCurrency } from "@/lib/format";
import { useLang } from "@/lib/i18n";
import { Plus, Pencil, Trash2, ChevronRight, ChevronLeft } from "lucide-react";
import { useForm } from "react-hook-form";

type WorkerForm = { name: string; role: string; phone: string };

function WorkerModal({ worker, onClose }: {
  worker?: { id: number; name: string; role: string; phone?: string | null };
  onClose: () => void;
}) {
  const { t } = useLang();
  const queryClient = useQueryClient();
  const createWorker = useCreateWorker();
  const updateWorker = useUpdateWorker();
  const { register, handleSubmit, formState: { errors } } = useForm<WorkerForm>({
    defaultValues: { name: worker?.name ?? "", role: worker?.role ?? "", phone: worker?.phone ?? "" },
  });

  const onSubmit = (data: WorkerForm) => {
    const payload = { name: data.name, role: data.role, phone: data.phone || null };
    if (worker) {
      updateWorker.mutate({ id: worker.id, data: payload }, {
        onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListWorkersQueryKey() }); onClose(); }
      });
    } else {
      createWorker.mutate({ data: payload }, {
        onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListWorkersQueryKey() }); onClose(); }
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="bg-card border border-card-border rounded-lg shadow-xl w-full max-w-md">
        <div className="p-5 border-b border-border">
          <h2 className="font-semibold text-foreground">{worker ? t.editWorker : t.newWorker}</h2>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.name} *</label>
            <input {...register("name", { required: true })} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder={t.namePlaceholder} />
            {errors.name && <p className="text-destructive text-xs mt-1">{t.nameRequired}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.role} *</label>
            <input {...register("role", { required: true })} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder={t.rolePlaceholder} />
            {errors.role && <p className="text-destructive text-xs mt-1">{t.roleRequired}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.phone}</label>
            <input {...register("phone")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder={t.phonePlaceholder} />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm border border-border rounded-md text-foreground hover:bg-muted transition-colors">{t.cancel}</button>
            <button type="submit" className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-md font-medium hover:opacity-90 transition-opacity" disabled={createWorker.isPending || updateWorker.isPending}>
              {worker ? t.save : t.create}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function Workers() {
  const [modal, setModal] = useState<{ open: boolean; worker?: { id: number; name: string; role: string; phone?: string | null } }>({ open: false });
  const { t } = useLang();
  const queryClient = useQueryClient();
  const { data: workers, isLoading } = useListWorkers();
  const deleteWorker = useDeleteWorker();

  const handleDelete = (id: number) => {
    if (confirm(t.deleteWorkerConfirm)) {
      deleteWorker.mutate({ id }, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: getListWorkersQueryKey() })
      });
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">{t.workersTitle}</h1>
          <p className="text-muted-foreground text-sm mt-0.5">{t.worker_count(workers?.length ?? 0)}</p>
        </div>
        <button onClick={() => setModal({ open: true })} className="flex items-center gap-1.5 px-3 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:opacity-90 transition-opacity">
          <Plus size={16} />
          {t.addWorker}
        </button>
      </div>

      {isLoading ? (
        <div className="space-y-2">
          {[...Array(3)].map((_, i) => <div key={i} className="h-16 bg-card border border-card-border rounded-lg animate-pulse" />)}
        </div>
      ) : workers?.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground"><p>{t.noWorkers}</p></div>
      ) : (
        <div className="space-y-2">
          {workers?.map((w) => (
            <div key={w.id} className="bg-card border border-card-border rounded-lg px-4 py-3 flex items-center justify-between hover:shadow-sm transition-shadow">
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground text-sm">{w.name}</p>
                <p className="text-muted-foreground text-xs">{w.role}{w.phone ? ` · ${w.phone}` : ""}</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className={`font-bold text-sm ${w.balance >= 0 ? "text-green-700" : "text-destructive"}`}>
                    {formatCurrency(w.balance)}
                  </p>
                  <p className="text-muted-foreground text-xs">{w.balance >= 0 ? t.toReceive : t.owes}</p>
                </div>
                <div className="flex items-center gap-1">
                  <button onClick={() => setModal({ open: true, worker: w })} className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors">
                    <Pencil size={14} />
                  </button>
                  <button onClick={() => handleDelete(w.id)} className="p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded transition-colors">
                    <Trash2 size={14} />
                  </button>
                  <Link href={`/workers/${w.id}`}>
                    <div className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors cursor-pointer">
                      <ChevronRight size={14} />
                    </div>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {modal.open && <WorkerModal worker={modal.worker} onClose={() => setModal({ open: false })} />}
    </div>
  );
}
