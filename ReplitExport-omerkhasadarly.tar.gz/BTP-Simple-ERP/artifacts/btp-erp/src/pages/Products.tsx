import { useState } from "react";
import { useListProducts, useCreateProduct, useUpdateProduct, useDeleteProduct, useListSuppliers, getListProductsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useLang } from "@/lib/i18n";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { useForm } from "react-hook-form";

type ProductForm = { name: string; supplierId: string };

function ProductModal({ product, onClose }: {
  product?: { id: number; name: string; supplierId?: number | null };
  onClose: () => void;
}) {
  const { t } = useLang();
  const queryClient = useQueryClient();
  const createProduct = useCreateProduct();
  const updateProduct = useUpdateProduct();
  const { data: suppliers } = useListSuppliers();
  const { register, handleSubmit, formState: { errors } } = useForm<ProductForm>({
    defaultValues: { name: product?.name ?? "", supplierId: product?.supplierId != null ? String(product.supplierId) : "" }
  });

  const onSubmit = (data: ProductForm) => {
    const payload = { name: data.name, supplierId: data.supplierId ? Number(data.supplierId) : null };
    if (product) {
      updateProduct.mutate({ id: product.id, data: payload }, {
        onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() }); onClose(); }
      });
    } else {
      createProduct.mutate({ data: payload }, {
        onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() }); onClose(); }
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="bg-card border border-card-border rounded-lg shadow-xl w-full max-w-md">
        <div className="p-5 border-b border-border">
          <h2 className="font-semibold text-foreground">{product ? t.editProduct : t.newProduct}</h2>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-3">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.name} *</label>
            <input {...register("name", { required: true })} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder="Portland Cement" />
            {errors.name && <p className="text-destructive text-xs mt-1">{t.nameRequired}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">{t.supplierLabel}</label>
            <select {...register("supplierId")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
              <option value="">{t.noneOption}</option>
              {suppliers?.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm border border-border rounded-md text-foreground hover:bg-muted transition-colors">{t.cancel}</button>
            <button type="submit" className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-md font-medium hover:opacity-90 transition-opacity" disabled={createProduct.isPending || updateProduct.isPending}>
              {product ? t.save : t.create}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function Products() {
  const [modal, setModal] = useState<{ open: boolean; product?: Parameters<typeof ProductModal>[0]["product"] }>({ open: false });
  const { t } = useLang();
  const queryClient = useQueryClient();
  const { data: products, isLoading } = useListProducts();
  const deleteProduct = useDeleteProduct();

  const handleDelete = (id: number) => {
    if (confirm(t.deleteProductConfirm)) {
      deleteProduct.mutate({ id }, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() })
      });
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">{t.productsTitle}</h1>
          <p className="text-muted-foreground text-sm mt-0.5">{t.product_count(products?.length ?? 0)}</p>
        </div>
        <button onClick={() => setModal({ open: true })} className="flex items-center gap-1.5 px-3 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:opacity-90 transition-opacity">
          <Plus size={16} />
          {t.addProduct}
        </button>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(3)].map((_, i) => <div key={i} className="h-14 bg-card border border-card-border rounded-lg animate-pulse" />)}</div>
      ) : products?.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground"><p>{t.noProducts}</p></div>
      ) : (
        <div className="space-y-2">
          {products?.map((p) => (
            <div key={p.id} className="bg-card border border-card-border rounded-lg px-4 py-3 flex items-center justify-between hover:shadow-sm transition-shadow">
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground text-sm">{p.name}</p>
                {p.supplierName && <p className="text-muted-foreground text-xs">{t.supplier_prefix}: {p.supplierName}</p>}
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button onClick={() => setModal({ open: true, product: p })} className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors">
                  <Pencil size={14} />
                </button>
                <button onClick={() => handleDelete(p.id)} className="p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded transition-colors">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {modal.open && <ProductModal product={modal.product} onClose={() => setModal({ open: false })} />}
    </div>
  );
}
