export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(amount);
}

export function formatDate(date: string | Date | null | undefined): string {
  if (!date) return "-";
  return new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "2-digit", year: "numeric" }).format(new Date(date));
}

export function formatDateInput(date: string | Date | null | undefined): string {
  if (!date) return "";
  const d = new Date(date);
  return d.toISOString().split("T")[0];
}

export const statusLabels: Record<string, string> = {
  active: "Actif",
  completed: "Terminé",
  paused: "En pause",
  paid: "Payé",
  unpaid: "Impayé",
  partial: "Partiel",
  debit: "Débit",
  credit: "Crédit",
};

export const statusColors: Record<string, string> = {
  active: "bg-green-100 text-green-800",
  completed: "bg-blue-100 text-blue-800",
  paused: "bg-yellow-100 text-yellow-800",
  paid: "bg-green-100 text-green-800",
  unpaid: "bg-red-100 text-red-800",
  partial: "bg-orange-100 text-orange-800",
  debit: "bg-red-100 text-red-800",
  credit: "bg-green-100 text-green-800",
};
